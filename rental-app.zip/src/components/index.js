import FloatBtn from "./floatBtn";
import Header from "./header";
import ItemCard from "./itemCard";

const components = {
  Header,
  ItemCard,
  FloatBtn,
};
export default components;
