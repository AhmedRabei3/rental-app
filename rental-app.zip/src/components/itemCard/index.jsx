import "./styles.css";
import { Link } from "react-router-dom";

function ItemCard() {
  return <div className="item-container"></div>;
}

export default ItemCard;
