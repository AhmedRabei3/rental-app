function FloatBtn() {
  return <div>FloatBtn</div>;
}

export default FloatBtn;
