import "./styles.css";

import React from "react";

function UserDashBoard() {
  return <div>UserDashBoard</div>;
}

export default UserDashBoard;
