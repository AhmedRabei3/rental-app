import "./styles.css";
import { Link } from "react-router-dom";
/* import {
  FaFacebookF,
  FaInstagram,
  FaTwitter,
  FaLinkedinIn,
  FaEnvelope,
} from "react-icons/fa"; */

import React from "react";

function ContactUs() {
  return <div>ContactUs</div>;
}

export default ContactUs;
