import "./styles.css";

function ItemDetails() {
  return <div>ItemDetails</div>;
}

export default ItemDetails;
