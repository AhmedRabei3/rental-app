import "./styles.css";
import { Link } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

import React from "react";

function RestPassword() {
  return <div>RestPassword</div>;
}

export default RestPassword;
